package com.itphutran.service;

import java.util.List;

import com.itphutran.model.Category;
import com.itphutran.model.News;

public interface NewsService {
	public List<News> getItems();

	public News getItem(int id);

	public void delItem(int id);

	public void saveItem(News category);

	public void editItem(News category);
}
