package com.itphutran.service;

import java.util.List;

import com.itphutran.model.Category;

public interface CoreService {
	public List<Category> getItems();

	public Category getItem(int id);

	public void delItem(int id);

	public void saveItem(Category category);

	public void editItem(Category category);
}
