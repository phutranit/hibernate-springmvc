package com.itphutran.service;

import java.util.List;

import com.itphutran.model.Keywork;

public interface KeyworkService {
	public List<Keywork> getItems();

	public Keywork getItem(int id);

	public void delItem(int id);

	public void saveItem(Keywork category);

	public void editItem(Keywork category);
}
