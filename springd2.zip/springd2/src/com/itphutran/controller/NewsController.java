package com.itphutran.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import com.itphutran.dao.NewsDao;
import com.itphutran.model.Category;
import com.itphutran.model.Keywork;
import com.itphutran.model.News;

@Controller
@RequestMapping("news")
public class NewsController {
	@Autowired
	private NewsDao newsDao;

	@GetMapping("")
	public String index() {
		System.out.println("Size of list news : " + newsDao.getItems().size());
		System.out.println("//////////////////////");
		System.out.println(newsDao.getItems().get(0).getCategory());
		return "index";
	}
	
	@GetMapping("save")
	public String save() {
		System.out.println("loading...");
		Keywork keywork2 = new Keywork(0, "keywork1", null);
		Keywork keywork3 = new Keywork(0, "keywork2", null);
		Keywork keywork4 = new Keywork(0, "keywork3", null);
		List<Keywork> listKeys = new ArrayList<>();
		listKeys.add(keywork2);
		listKeys.add(keywork3);
		listKeys.add(keywork4);
		News news = new News(0, "Tn tin moi themmmmmmmmmm", listKeys);
		newsDao.saveItem(news);
		System.out.println("Handle success!");
		return "index";
	}
}
