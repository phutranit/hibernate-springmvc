package com.itphutran.controller;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;

import com.itphutran.dao.CategoryDao;
import com.itphutran.dao.KeyworkDao;
import com.itphutran.model.Category;
import com.itphutran.model.Keywork;
import com.itphutran.model.News;

@Controller
@RequestMapping("keywork")
public class KeyWorkController {
	@Autowired
	private CategoryDao catDao;
	
	@Autowired
	private KeyworkDao keyworkDao;

	@GetMapping("")
	public String index() {
		System.out.println("Size list of cat : " + catDao.getItems().size());
		System.out.println("/////////////////////////");
		System.out.println(catDao.getItems().get(0).getNewss());
		return "cat/index";
	}

	@GetMapping("{id}")
	public String getItem(@PathVariable int id) {
		System.out.println(catDao.getItem(id).toString());
		return "cat/index";
	}

	@GetMapping("del/{id}")
	public String del(@PathVariable int id) {
		System.out.println("first size : ");
		System.out.println(catDao.getItems().size());
		catDao.delItem(id);
		System.out.println("before size : ");
		System.out.println(catDao.getItems().size());
		return "cat/index";
	}

	@GetMapping("save")
	public String saveItem() {
		System.out.println("loading...");
		List<News> listNews = new ArrayList<>();
		listNews.add(new News(0, 12, 45, "Tieu de 1", "mo ta moi them 1", "hinh 1", "Dia chi 1", new Date(),
				new Category(0, "Danh muc moi them 1")));
		listNews.add(new News(0, 12, 45, "Tieu de 2", "mo ta moi them 2", "hinh 2", "Dia chi 1", new Date(),
				new Category(0, "Danh muc moi them 2")));
		Keywork keywork = new Keywork(0, "keywork1", listNews);
		keyworkDao.saveItem(keywork);
		System.out.println("Handle success!");
		return "cat/index";
	}

	@GetMapping("edit/{id}")
	public String updateItem(@PathVariable int id) {
		catDao.editItem(new Category(id, "Phu TTTTTTTTTTT"));
		System.out.println("category before update : ");
		System.out.println(catDao.getItem(id));
		return "cat/index";
	}
}
