package com.itphutran.model;

import java.sql.Timestamp;
import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.ManyToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;

import org.springframework.format.annotation.DateTimeFormat;

@Entity
@Table(name = "lands")
public class News {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int lid;
	private int count_views;
	private float area;
	private String lname;
	private String description;
	private String picture;
	private String address;
	@Temporal(TemporalType.DATE)
	@DateTimeFormat(pattern = "dd/MM/yyyy")
	private Date date_create;
	@ManyToOne(cascade = CascadeType.ALL)
	@JoinColumn(name = "cid")
	private Category category;
	
	@ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinTable(name = "news_keywork", joinColumns = 
			@JoinColumn(nullable = false, name = "newsId", referencedColumnName = "lid"),
			inverseJoinColumns = @JoinColumn(nullable = false, name = "kid", referencedColumnName = "kid"))
	private List<Keywork> keyworks;

	public int getLid() {
		return lid;
	}

	public void setLid(int lid) {
		this.lid = lid;
	}

	public int getCount_views() {
		return count_views;
	}

	public void setCount_views(int count_views) {
		this.count_views = count_views;
	}

	public float getArea() {
		return area;
	}

	public void setArea(float area) {
		this.area = area;
	}

	public String getLname() {
		return lname;
	}

	public void setLname(String lname) {
		this.lname = lname;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getPicture() {
		return picture;
	}

	public void setPicture(String picture) {
		this.picture = picture;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public Date getDate_create() {
		return date_create;
	}

	public void setDate_create(Date date_create) {
		this.date_create = date_create;
	}

	public Category getCategory() {
		return category;
	}

	public void setCategory(Category category) {
		this.category = category;
	}

	public List<Keywork> getKeyworks() {
		return keyworks;
	}

	public void setKeyworks(List<Keywork> keyworks) {
		this.keyworks = keyworks;
	}

	public News(int lid, int count_views, float area, String lname, String description, String picture, String address,
			Date date_create, Category category) {
		super();
		this.lid = lid;
		this.count_views = count_views;
		this.area = area;
		this.lname = lname;
		this.description = description;
		this.picture = picture;
		this.address = address;
		this.date_create = date_create;
		this.category = category;
	}

	public News() {
	}

	public News(int lid, String lname, List<Keywork> keyworks) {
		this.lid = lid;
		this.lname = lname;
		this.keyworks = keyworks;
	}

	@Override
	public String toString() {
		return "News [lid=" + lid + ", count_views=" + count_views + ", area=" + area + ", lname=" + lname
				+ ", description=" + description + ", picture=" + picture + ", address=" + address + ", date_create="
				+ date_create + ", category=" + category + "]";
	}

}
