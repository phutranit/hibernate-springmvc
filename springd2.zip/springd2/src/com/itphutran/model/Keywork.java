package com.itphutran.model;

import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.Table;

@Entity
@Table(name = "keywork")
public class Keywork {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int kid;
	private String kname;
	@ManyToMany(cascade = CascadeType.ALL, fetch = FetchType.LAZY)
	@JoinTable(name = "news_keywork", joinColumns = @JoinColumn(nullable = false, name = "kid", referencedColumnName = "kid"), inverseJoinColumns = @JoinColumn(nullable = false, name = "newsId", referencedColumnName = "lid"))
	private List<News> news;

	public int getKid() {
		return kid;
	}

	public void setKid(int kid) {
		this.kid = kid;
	}

	public String getKname() {
		return kname;
	}

	public void setKname(String kname) {
		this.kname = kname;
	}

	public List<News> getNews() {
		return news;
	}

	public void setNews(List<News> news) {
		this.news = news;
	}

	public Keywork(int kid, String kname, List<News> news) {
		this.kid = kid;
		this.kname = kname;
		this.news = news;
	}

	public Keywork() {
		super();
	}

}
