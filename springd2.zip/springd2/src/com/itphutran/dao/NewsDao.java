package com.itphutran.dao;

import java.util.List;

import javax.transaction.Transactional;

import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.itphutran.model.News;
import com.itphutran.service.NewsService;

@Repository
@Transactional
public class NewsDao implements NewsService {
	@Autowired
	private SessionFactory sessionFactory;

	@SuppressWarnings("unchecked")
	@Override
	public List<News> getItems() {
		Session session = sessionFactory.getCurrentSession();
		String sql = "FROM News";
		return session.createQuery(sql).list();
	}

	@Override
	public News getItem(int id) {
		Session session = sessionFactory.getCurrentSession();
		return session.createQuery("FROM Category WHERE cid = ?", News.class).setParameter(0, id).uniqueResult();
	}

	@Override
	public void delItem(int id) {
		Session session = sessionFactory.getCurrentSession();
		session.delete(session.find(News.class, id));
	}
	
	@Override
	public void saveItem(News news) {
		Session session = sessionFactory.getCurrentSession();
		session.save(news);
	}

	@Override
	public void editItem(News category) {
			
	}
	

}
